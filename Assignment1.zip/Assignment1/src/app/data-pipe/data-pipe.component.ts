import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-pipe',
  templateUrl: './data-pipe.component.html',
  styleUrls: ['./data-pipe.component.css']
})
export class DataPipeComponent implements OnInit {
fname="kartik";
lname="chaudhary";
address="pune, maharashtra";
gender=1;
dob=new Date();
empid=1456452;
marks=87.4532;


  constructor() { }

  ngOnInit(): void {
  }

}
