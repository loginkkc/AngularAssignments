import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataPipeComponent } from './data-pipe.component';

describe('DataPipeComponent', () => {
  let component: DataPipeComponent;
  let fixture: ComponentFixture<DataPipeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataPipeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataPipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
