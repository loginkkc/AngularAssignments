import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { DGREENcolorDirective } from './d-greencolor.directive';
import { DREDcolorDirective } from './d-redcolor.directive';
import { ColorDirectivesComponent } from './color-directives/color-directives.component';
import { StyleclassesComponent } from './styleclasses/styleclasses.component';
import { DateServiceService } from './date-service.service';
import { DataPipeComponent } from './data-pipe/data-pipe.component';
import { GenderPipe } from './gender.pipe';
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    DGREENcolorDirective,
    DREDcolorDirective,
    ColorDirectivesComponent,
    StyleclassesComponent,
    DataPipeComponent,
    GenderPipe
  ],
  imports: [
    BrowserModule
  ],
  providers: [DateServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
