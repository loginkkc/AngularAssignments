import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appDREDcolor]'
})
export class DREDcolorDirective {

    constructor(e:ElementRef) {

    e.nativeElement.style.color='red';
   }


}
