import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {


emp=[{
        "id": "1",
        "firstName": "Tom",
        "lastName": "Cruise",
        "gender":1,
        "mobile":"927154655",
        "pan":"GEPWL5833G"

      },
      {
        "id": "2",
        "firstName": "Maria",
        "lastName": "Sharapova",
        "gender":2,
        "mobile":"345433452",
        "pan":"FGFFGD3443"
      },
      {
        "id": "3",
        "firstName": "James",
        "lastName": "Bond",
        "gender":3,
        "mobile":"435345345",
        "pan":"GEDDF34333G"
      },
       {
        "id": "4",
        "firstName": "Kartik",
        "lastName": "Chaudhary",
        "gender":1,
        "mobile":"345345523",
        "pan":"GHFWL3434G"
      },
      {
        "id": "5",
        "firstName": "Prasad",
        "lastName": "Chaudhary",
        "gender":1,
        "mobile":"456544335",
        "pan":"FGDGWL534343G"
      }
]
  
  constructor() { }

  ngOnInit(): void {
  }

}
