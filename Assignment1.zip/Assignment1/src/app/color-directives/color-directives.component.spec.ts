import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ColorDirectivesComponent } from './color-directives.component';

describe('ColorDirectivesComponent', () => {
  let component: ColorDirectivesComponent;
  let fixture: ComponentFixture<ColorDirectivesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ColorDirectivesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ColorDirectivesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
