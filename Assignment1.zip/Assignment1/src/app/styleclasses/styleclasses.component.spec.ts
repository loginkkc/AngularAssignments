import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StyleclassesComponent } from './styleclasses.component';

describe('StyleclassesComponent', () => {
  let component: StyleclassesComponent;
  let fixture: ComponentFixture<StyleclassesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StyleclassesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StyleclassesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
