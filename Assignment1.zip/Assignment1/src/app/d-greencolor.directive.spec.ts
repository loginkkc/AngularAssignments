import { DGREENcolorDirective } from './d-greencolor.directive';

describe('DGREENcolorDirective', () => {
  it('should create an instance', () => {
    const directive = new DGREENcolorDirective();
    expect(directive).toBeTruthy();
  });
});
