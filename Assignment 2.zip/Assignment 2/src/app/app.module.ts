import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { DGREENcolorDirective } from './d-greencolor.directive';
import { DREDcolorDirective } from './d-redcolor.directive';
import { ColorDirectivesComponent } from './color-directives/color-directives.component';
import { StyleclassesComponent } from './styleclasses/styleclasses.component';
import { DateServiceService } from './date-service.service';
import { GenderPipe } from './gender.pipe';
import { SortPipe } from './sort.pipe';
import { AppRoutingModule } from './app-routing.module';
import { HtvalidationsComponent } from './htvalidations/htvalidations.component';
import { ReactiveWebComponent } from './reactive-web/reactive-web.component';
import { PipesuseComponent } from './pipesuse/pipesuse.component';
import { HttpClientModule, HttpClient} from '@angular/common/http';
import { CrudhttpcompComponent } from './crudhttpcomp/crudhttpcomp.component';
import { CrudhttpclientService } from './crudhttpclient.service';
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    DGREENcolorDirective,
    DREDcolorDirective,
    ColorDirectivesComponent,
    StyleclassesComponent,
    GenderPipe,
    SortPipe,
    HtvalidationsComponent,
    ReactiveWebComponent,
    PipesuseComponent,
    CrudhttpcompComponent,
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
  ],
  providers: [DateServiceService,CrudhttpclientService],
  bootstrap: [AppComponent]
})
export class AppModule { }
