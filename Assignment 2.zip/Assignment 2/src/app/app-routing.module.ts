import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HtvalidationsComponent} from './htvalidations/htvalidations.component'
import { EmployeeComponent} from './employee/employee.component'
import { StyleclassesComponent} from './styleclasses/styleclasses.component'
import { ColorDirectivesComponent } from './color-directives/color-directives.component';
import { PipesuseComponent } from './pipesuse/pipesuse.component';
import { CrudhttpcompComponent } from './crudhttpcomp/crudhttpcomp.component';


const routes: Routes = [
  { path: 'htvalidations', component: HtvalidationsComponent },
  { path:'employeecomp',component:EmployeeComponent},
  { path:'styleclasses',component:StyleclassesComponent},
  { path:'colordirectives',component:ColorDirectivesComponent},
  { path:'pipesuse',component:PipesuseComponent},
  { path:'crudhttp',component:CrudhttpcompComponent}
  
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,[RouterModule.forRoot(routes)]
  ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
