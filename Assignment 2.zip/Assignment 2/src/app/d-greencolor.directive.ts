import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appDGREENcolor]'
})
export class DGREENcolorDirective {

  
  constructor(e:ElementRef) {

    e.nativeElement.style.color='#008000';
   }

}
