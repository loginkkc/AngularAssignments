import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReactiveWebComponent } from './reactive-web.component';

describe('ReactiveWebComponent', () => {
  let component: ReactiveWebComponent;
  let fixture: ComponentFixture<ReactiveWebComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReactiveWebComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReactiveWebComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
