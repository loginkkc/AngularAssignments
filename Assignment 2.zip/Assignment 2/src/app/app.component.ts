import { Component } from '@angular/core';
import { DateServiceService } from './date-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular Assignments';
  date;
constructor(private d:DateServiceService){
this.date=d.getdate();
}
}
