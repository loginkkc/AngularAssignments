import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-htvalidations',
  templateUrl: './htvalidations.component.html',
  styleUrls: ['./htvalidations.component.css']
})
export class HtvalidationsComponent implements OnInit {

onSubmit(a:any){
  
}
  constructor() { }

  ngOnInit(): void {
  }

}
