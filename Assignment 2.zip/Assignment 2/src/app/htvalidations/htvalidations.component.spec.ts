import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HtvalidationsComponent } from './htvalidations.component';

describe('HtvalidationsComponent', () => {
  let component: HtvalidationsComponent;
  let fixture: ComponentFixture<HtvalidationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HtvalidationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HtvalidationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
