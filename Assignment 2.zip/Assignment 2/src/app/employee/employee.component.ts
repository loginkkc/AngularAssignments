import { Component, OnInit } from '@angular/core';
import { EmpDataService } from '../emp-data.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers:[EmpDataService],
})
export class EmployeeComponent implements OnInit {
  filterfname='asc';
  filterlname='asc';
  filtermobile='asc';
  filtergender='asc';
  filterpan='asc';
  filterid='asc';
  colname='id';
  colorder='asc';
  action='Add';
  emp:any[];
  input:any={};
  idx:number;
  sortcolumn(colname:any){

    switch(colname)
    {
      case 'id':
      this.colorder=this.filterid;
      this.colname='id';
          if(this.filterid==='asc')
          this.filterid='dsc';
          else
          this.filterid='asc';
       break;

      case 'firstName': 
      this.colorder=this.filterfname;
      this.colname='firstName';
          if(this.filterfname==='asc')
          this.filterfname='dsc';
          else
          this.filterfname='asc';
       break;

       case 'lastName':
        this.colorder=this.filterlname; 
       this.colname='lastName';
          if(this.filterlname==='asc')
          this.filterlname='dsc';
          else
          this.filterlname='asc';
       break;

       case 'mobile': 
       this.colorder=this.filtermobile;
       this.colname='mobile';
          if(this.filtermobile==='asc')
          this.filtermobile='dsc';
          else
          this.filtermobile='asc';
       break;

       case 'gender':
        this.colorder=this.filtergender; 
       this.colname='gender';
          if(this.filtergender==='asc')
          this.filtergender='dsc';
          else
          this.filtergender='asc';
       break;

       case 'pan':
        this.colorder=this.filterpan;
        this.colname='pan';
          if(this.filterpan==='asc')
          this.filterpan='dsc';
          else
          this.filterpan='asc';
       break;
      
    }
    
  }

  constructor(ss:EmpDataService) {
    this.emp=ss.getEmpData();
   }

  ngOnInit(): void {
  }

  addData(action:any){
    if(action==='Add')
    {
      this .emp.push(this.input)
      alert("Data Added Successfully.");
    }else if(action==='Update'){
      this.emp[this.idx].id=this.input.id;
      this.emp[this.idx].firstName=this.input.firstName;
      this.emp[this.idx].lastName=this.input.lastName;
      this.emp[this.idx].mobile=this.input.mobile;
      this.emp[this.idx].pan=this.input.pan;
      alert("Data Updated Successfully.");
    }
    this.input={};
    this.action="Add";
   
  }

  updateEmp(uid:any){
    this.input.id=this.emp[uid].id;
    this.input.firstName=this.emp[uid].firstName;
    this.input.lastName=this.emp[uid].lastName;
    this.input.mobile=this.emp[uid].mobile;
    this.input.pan=this.emp[uid].pan;
    this.action='Update';
    this.idx=uid;
  }
  deleteEmp(index:number){
    if(confirm("Are you sure to delete this record"))
    {this.emp.splice(index, 1);
      alert("Record Deleted Successfully.");
    }

  }
}

