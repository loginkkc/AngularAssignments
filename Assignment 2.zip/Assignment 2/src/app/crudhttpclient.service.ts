import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CrudhttpclientService {
  private apiurl = "http://jsonplaceholder.typicode.com/posts";

   constructor(private http: HttpClient) { }
   getdata() {
      return this.http.get(this.apiurl);
   }


}
