import { DREDcolorDirective } from './d-redcolor.directive';

describe('DREDcolorDirective', () => {
  it('should create an instance', () => {
    const directive = new DREDcolorDirective();
    expect(directive).toBeTruthy();
  });
});
