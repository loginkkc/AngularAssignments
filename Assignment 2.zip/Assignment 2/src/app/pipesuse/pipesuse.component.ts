import { Component, OnInit } from '@angular/core';
import { EmpDataService } from '../emp-data.service';

@Component({
  selector: 'app-pipesuse',
  templateUrl: './pipesuse.component.html',
  styleUrls: ['./pipesuse.component.css'],
  providers:[EmpDataService],
})
export class PipesuseComponent implements OnInit {
  fname="kartik";
  lname="chaudhary";
  address="pune, maharashtra";
  gender=1;
  dob=new Date();
  empid=1456452;
  marks=87.4532;
  emps:any=[{}];
  constructor(es:EmpDataService) { 

    this.emps=es.getEmpData();
  }

  ngOnInit(): void {
  }

}
