import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-styleclasses',
  templateUrl: './styleclasses.component.html',
  styleUrls: ['./styleclasses.component.css']
})
export class StyleclassesComponent implements OnInit {
color=['red','orange','green','yello','purple'];
  constructor() { }

  ngOnInit(): void {
  }

}
