import { TestBed } from '@angular/core/testing';

import { CrudhttpclientService } from './crudhttpclient.service';

describe('CrudhttpclientService', () => {
  let service: CrudhttpclientService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CrudhttpclientService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
