import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-color-directives',
  templateUrl: './color-directives.component.html',
  styleUrls: ['./color-directives.component.css']
})
export class ColorDirectivesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
