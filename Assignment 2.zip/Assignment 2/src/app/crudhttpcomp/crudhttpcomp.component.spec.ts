import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrudhttpcompComponent } from './crudhttpcomp.component';

describe('CrudhttpcompComponent', () => {
  let component: CrudhttpcompComponent;
  let fixture: ComponentFixture<CrudhttpcompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrudhttpcompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrudhttpcompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
