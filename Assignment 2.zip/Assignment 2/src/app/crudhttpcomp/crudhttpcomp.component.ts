import { Component, OnInit } from '@angular/core';
import { CrudhttpclientService } from '../crudhttpclient.service';

@Component({
  selector: 'app-crudhttpcomp',
  templateUrl: './crudhttpcomp.component.html',
  styleUrls: ['./crudhttpcomp.component.css'],
  providers:[CrudhttpclientService],
})
export class CrudhttpcompComponent implements OnInit {

  filterfname='asc';
  filterlname='asc';
  filtermobile='asc';
  filtergender='asc';
  filterpan='asc';
  filterid='asc';
  colname='id';
  colorder='asc';
  action='Add';
  emp:any;
  input:any={};
  idx:number;
  sortcolumn(colname:any){

    switch(colname)
    {
      case 'id':
      this.colorder=this.filterid;
      this.colname='id';
          if(this.filterid==='asc')
          this.filterid='dsc';
          else
          this.filterid='asc';
       break;

      case 'userId': 
      this.colorder=this.filterfname;
      this.colname='userId';
          if(this.filterfname==='asc')
          this.filterfname='dsc';
          else
          this.filterfname='asc';
       break;

       case 'title':
        this.colorder=this.filterlname; 
       this.colname='title';
          if(this.filterlname==='asc')
          this.filterlname='dsc';
          else
          this.filterlname='asc';
       break;

       case 'body': 
       this.colorder=this.filtermobile;
       this.colname='body';
          if(this.filtermobile==='asc')
          this.filtermobile='dsc';
          else
          this.filtermobile='asc';
       break;
      
    }
    
  }

 
  
  
  constructor(private es:CrudhttpclientService) {
   }

  ngOnInit(): void {
    this.es.getdata().subscribe((data) => {
      this.emp = Array.from(Object.keys(data), k=>data[k]);
   });

  }

  addData(action:any){
    if(action==='Add')
    {
      this .emp.push(this.input)
      alert("Data Added Successfully.");
    }else if(action==='Update'){
      this.emp[this.idx].id=this.input.id;
      this.emp[this.idx].userId=this.input.userId;
      this.emp[this.idx].title=this.input.title;
      this.emp[this.idx].body=this.input.body;
      alert("Data Updated Successfully.");
    }
    this.input={};
    this.action="Add";
   
  }

  updateEmp(uid:any){
    this.input.id=this.emp[uid].id;
    this.input.userId=this.emp[uid].userId;
    this.input.title=this.emp[uid].title;
    this.input.body=this.emp[uid].body;
    this.action='Update';
    this.idx=uid;
  }
  deleteEmp(index:number){
    if(confirm("Are you sure to delete this record"))
    {this.emp.splice(index, 1);
      alert("Record Deleted Successfully.");
    }

  }
  
}

