import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DateServiceService {
getdate(){
  return new Date();
}
  constructor() { }
}
